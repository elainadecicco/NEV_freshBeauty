/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"naasirhusainmahmadsafi.mirza@dcmail.ca","$P$BbTZjLZTwMSNKQgrpu3EUnXyMdY9an.","naasirhusainmahmadsafi-mirzadcmail-ca","naasirhusainmahmadsafi.mirza@dcmail.ca","","2020-02-08 03:58:22","",0,"naasirhusainmahmadsafi.mirza@dcmail.ca");
